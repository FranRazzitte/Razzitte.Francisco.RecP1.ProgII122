package razzittefranciscorecp1progii122;

import java.time.LocalDate;

public class Festival extends Espectaculo implements Transmitible {
    private int cantidadEscenarios;
    private boolean tieneCamping;

    public Festival(String nombre, LocalDate fecha, int duracionMinutos, int cantidadEscenarios, boolean tieneCamping) {
        super(nombre, fecha, duracionMinutos);
        this.cantidadEscenarios = cantidadEscenarios;
        this.tieneCamping = tieneCamping;
    }

    @Override
    public void transmitir() {
        System.out.println("Transmitiendo festival: " + getNombre());
    }

    @Override
    public String toString() {
        return super.toString() + ", Escenarios: " + cantidadEscenarios + ", Camping: " + (tieneCamping ? "Sí" : "No");
    }
}
