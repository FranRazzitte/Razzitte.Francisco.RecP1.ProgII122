package razzittefranciscorecp1progii122;

import java.time.LocalDate;
import java.util.ArrayList;

public class Concierto extends Espectaculo implements Transmitible, Calificable {
    private Genero genero;
    private ArrayList<String> artistas;

    public Concierto(String nombre, LocalDate fecha, int duracionMinutos, Genero genero, ArrayList<String> artistas) {
        super(nombre, fecha, duracionMinutos);
        this.genero = genero;
        this.artistas = artistas;
    }

    public Genero getGenero() {
        return genero;
    }

    public ArrayList<String> getArtistas() {
        return artistas;
    }

    @Override
    public void transmitir() {
        System.out.println("Transmitiendo concierto: " + getNombre());
    }

    @Override
    public void calificar(int puntaje) {
        System.out.println("El concierto recibió una calificación de " + puntaje);
    }

    @Override
    public String toString() {
        return super.toString() + ", Género: " + genero + ", Artistas: " + artistas;
    }
}
