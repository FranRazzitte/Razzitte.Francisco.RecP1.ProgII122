package razzittefranciscorecp1progii122;

public class EspectaculoDuplicado extends RuntimeException {
    public EspectaculoDuplicado(String mensaje) {
        super(mensaje);
    }
}
