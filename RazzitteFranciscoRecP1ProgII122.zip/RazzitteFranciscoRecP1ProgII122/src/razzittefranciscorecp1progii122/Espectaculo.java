package razzittefranciscorecp1progii122;

import java.time.LocalDate;

public abstract class Espectaculo {
    private String nombre;
    private LocalDate fecha;
    private int duracionMinutos;

    public Espectaculo(String nombre, LocalDate fecha, int duracionMinutos) {
        this.nombre = nombre;
        this.fecha = fecha;
        this.duracionMinutos = duracionMinutos;
    }

    public String getNombre() {
        return nombre;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public int getDuracionMinutos() {
        return duracionMinutos;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Espectaculo) {
            Espectaculo e = (Espectaculo) o;
            return this.nombre.equalsIgnoreCase(e.nombre) && this.fecha.equals(e.fecha);
        }
        return false;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Fecha: " + fecha + ", Duración: " + duracionMinutos + " min";
    }
}
