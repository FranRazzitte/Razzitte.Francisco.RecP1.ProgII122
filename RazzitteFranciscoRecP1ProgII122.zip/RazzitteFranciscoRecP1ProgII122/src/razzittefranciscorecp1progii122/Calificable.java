package razzittefranciscorecp1progii122;

public interface Calificable {
    void calificar(int puntaje);
}
