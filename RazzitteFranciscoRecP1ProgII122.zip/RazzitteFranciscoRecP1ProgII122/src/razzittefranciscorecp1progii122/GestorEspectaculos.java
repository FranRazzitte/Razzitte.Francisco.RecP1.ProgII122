package razzittefranciscorecp1progii122;

import java.util.ArrayList;

public class GestorEspectaculos {
    private ArrayList<Espectaculo> espectaculos = new ArrayList<>();

    public void agregarEspectaculo(Espectaculo e) {
        if (espectaculos.contains(e)) {
            throw new EspectaculoDuplicado("Ya existe un espectáculo con ese nombre y fecha.");
        } else {
            System.out.println(e.getNombre() + " agregado al sistema.");
        }
        espectaculos.add(e);
    }

    public void mostrarEspectaculos() {
        for (Espectaculo e : espectaculos) {
            System.out.println(e);
        }
    }

    public void transmitirEventos() {
        for (Espectaculo e : espectaculos) {
            if (e instanceof Transmitible) {
                ((Transmitible) e).transmitir();
            } else {
                System.out.println("No se puede transmitir: " + e.getNombre());
            }
        }
    }

    public void filtrarPorGenero(Genero g) {
        for (Espectaculo e : espectaculos) {
            if (e instanceof Concierto) {
                Concierto c = (Concierto) e;
                if (c.getGenero() == g) {
                    System.out.println(c);
                }
            }
        }
    }

    public void calificarEvento(String nombre, int puntaje) {
        boolean encontrado = false;
        for (Espectaculo e : espectaculos) {
            if (e.getNombre().equals(nombre)) {
                if (e instanceof Calificable) {
                    Calificable c = (Calificable) e;
                    c.calificar(puntaje);
                } else {
                    System.out.println("El espectáculo " + nombre + " no se puede calificar.");
                }
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontró el espectáculo: " + nombre);
        }
    }
}
