package razzittefranciscorecp1progii122;

public enum Genero {
    POP,
    ROCK,
    JAZZ
}
