package razzittefranciscorecp1progii122;

import java.time.LocalDate;
import java.util.ArrayList;

public class RazzitteFranciscoRecP1ProgII122 {
    public static void main(String[] args) {
        GestorEspectaculos gestor = new GestorEspectaculos();

        ArrayList<String> artistas = new ArrayList<>();
        artistas.add("Artista 1");
        artistas.add("Artista 2");

        Concierto c1 = new Concierto("Concierto A", LocalDate.of(2025, 7, 1), 120, Genero.ROCK, artistas);
        ObraTeatral o1 = new ObraTeatral("Obra X", LocalDate.of(2025, 7, 2), 90, Clasificacion.ATP, "Director 1");
        Festival f1 = new Festival("Festival Z", LocalDate.of(2025, 7, 3), 300, 5, true);

        try {
            gestor.agregarEspectaculo(c1);
            gestor.agregarEspectaculo(o1);
            gestor.agregarEspectaculo(f1);
            gestor.agregarEspectaculo(new Concierto("Concierto A", LocalDate.of(2025, 7, 1), 100, Genero.POP, artistas));
        } catch (EspectaculoDuplicado ex) {
            System.out.println(ex.getMessage());
        }

        gestor.mostrarEspectaculos();
        gestor.transmitirEventos();
        gestor.filtrarPorGenero(Genero.JAZZ);
        gestor.calificarEvento("Concierto A", 5);
        gestor.calificarEvento("Festival Z", 4);
    }
}
