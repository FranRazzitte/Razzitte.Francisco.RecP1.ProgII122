package razzittefranciscorecp1progii122;

public interface Transmitible {
    void transmitir();
}
