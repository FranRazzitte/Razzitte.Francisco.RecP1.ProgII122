package razzittefranciscorecp1progii122;

import java.time.LocalDate;
import java.util.ArrayList;

public class ObraTeatral extends Espectaculo implements Calificable {
    private Clasificacion clasificacion;
    private String director;

    public ObraTeatral(String nombre, LocalDate fecha, int duracionMinutos, Clasificacion clasificacion, String director) {
        super(nombre, fecha, duracionMinutos);
        this.clasificacion = clasificacion;
        this.director = director;
    }

    @Override
    public void calificar(int puntaje) {
        System.out.println("La obra teatral recibió una calificación de " + puntaje);
    }

    @Override
    public String toString() {
        return super.toString() + ", Clasificación: " + clasificacion + ", Director: " + director;
    }
}
