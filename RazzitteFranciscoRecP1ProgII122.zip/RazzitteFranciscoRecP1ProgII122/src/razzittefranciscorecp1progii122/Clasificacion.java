package razzittefranciscorecp1progii122;

public enum Clasificacion {
    ATP,
    MAYOR13,
    MAYOR18
}
